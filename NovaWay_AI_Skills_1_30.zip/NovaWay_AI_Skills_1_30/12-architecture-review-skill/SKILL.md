# 12-architecture-review-skill — Architecture Review

## Purpose

Review kiến trúc trước khi code hoặc trước khi merge phase lớn.

## When to use

Use this skill when NovaWay needs to make a decision, write a document, review a phase, or prepare a prompt related to **Architecture Review**.

## Inputs

- Architecture doc
- Data model
- API contract
- Micro-step plan

## Outputs

- `docs/ARCHITECTURE_REVIEW.md`
- `docs/TECH_DECISIONS.md`

## Step-by-step process

1. Read the current project baseline:
   - `README.md`
   - `AGENTS.md`
   - `docs/PRD.md`
   - `docs/SRS.md`
   - `docs/ARCHITECTURE.md`
   - `docs/ROADMAP.md`
   - `docs/PHASES.md`
2. Identify the exact phase, branch, and micro-step being worked on.
3. Extract only the requirements relevant to this skill.
4. Write or update the output documents listed above.
5. Add open questions to `docs/01_OPEN_QUESTIONS.md` instead of guessing.
6. Add risks to `docs/RISK_REGISTER.md` when a decision can affect security, reliability, cost, or schedule.
7. Produce a test/checklist section before handing off to Codex or Claude Code.

## Required checklist

- [ ] Không có dependency vòng
- [ ] Không có coupling quá mức
- [ ] Có trade-off
- [ ] Có quyết định kiến trúc

## Handoff format

When this skill finishes, produce this summary:

```text
Skill used: 12-architecture-review-skill
Phase:
Branch:
Files created/updated:
Decisions made:
Open questions:
Risks:
Next recommended step:
Test gate:
```

## Prompt template

```text
Role: NovaWay Architecture Review Specialist.

Task:
Use the 12-architecture-review-skill to support the current NovaWay step.

Context:
- Current phase:
- Current branch:
- Current target:
- Related docs:
- Constraints:

Requirements:
1. Do not invent product requirements.
2. If a requirement is missing, write it as an open question.
3. Keep the output small enough for AI coding agents to follow.
4. Add acceptance criteria or test gates where relevant.
5. Do not move to code until the documentation gate is passed.

Expected output:
- Updated document sections
- Checklist
- Open questions
- Risks
- Next action
```

## Done definition

This skill is done only when:
- Không có dependency vòng
- Không có coupling quá mức
- Có trade-off
- Có quyết định kiến trúc
