# 15-pr-release-governance-skill — PR Release Governance

## Purpose

Quản trị PR, branch, commit convention, merge develop/main và release gate.

## When to use

Use this skill when NovaWay needs to make a decision, write a document, review a phase, or prepare a prompt related to **PR Release Governance**.

## Inputs

- Git workflow
- Branch plan
- Test result
- Review notes

## Outputs

- `docs/GIT_WORKFLOW.md`
- `docs/PR_TEMPLATE.md`
- `docs/MERGE_CHECKLIST.md`

## Step-by-step process

1. Read the current project baseline:
   - `README.md`
   - `AGENTS.md`
   - `docs/PRD.md`
   - `docs/SRS.md`
   - `docs/ARCHITECTURE.md`
   - `docs/ROADMAP.md`
   - `docs/PHASES.md`
2. Identify the exact phase, branch, and micro-step being worked on.
3. Extract only the requirements relevant to this skill.
4. Write or update the output documents listed above.
5. Add open questions to `docs/01_OPEN_QUESTIONS.md` instead of guessing.
6. Add risks to `docs/RISK_REGISTER.md` when a decision can affect security, reliability, cost, or schedule.
7. Produce a test/checklist section before handing off to Codex or Claude Code.

## Required checklist

- [ ] PR nhỏ
- [ ] Commit đúng type
- [ ] Test develop trước main
- [ ] Có checklist merge

## Handoff format

When this skill finishes, produce this summary:

```text
Skill used: 15-pr-release-governance-skill
Phase:
Branch:
Files created/updated:
Decisions made:
Open questions:
Risks:
Next recommended step:
Test gate:
```

## Prompt template

```text
Role: NovaWay PR Release Governance Specialist.

Task:
Use the 15-pr-release-governance-skill to support the current NovaWay step.

Context:
- Current phase:
- Current branch:
- Current target:
- Related docs:
- Constraints:

Requirements:
1. Do not invent product requirements.
2. If a requirement is missing, write it as an open question.
3. Keep the output small enough for AI coding agents to follow.
4. Add acceptance criteria or test gates where relevant.
5. Do not move to code until the documentation gate is passed.

Expected output:
- Updated document sections
- Checklist
- Open questions
- Risks
- Next action
```

## Done definition

This skill is done only when:
- PR nhỏ
- Commit đúng type
- Test develop trước main
- Có checklist merge
