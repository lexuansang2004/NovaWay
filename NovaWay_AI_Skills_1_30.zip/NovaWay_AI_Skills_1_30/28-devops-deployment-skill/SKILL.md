# 28-devops-deployment-skill — DevOps Deployment

## Purpose

Thiết kế Docker, env, CI/CD, deploy backend/web/database/cache và test gate trước merge.

## When to use

Use this skill when NovaWay needs to make a decision, write a document, review a phase, or prepare a prompt related to **DevOps Deployment**.

## Inputs

- Repo foundation
- Tech stack
- Infrastructure needs
- Git workflow

## Outputs

- `docs/DEVOPS_DEPLOYMENT.md`
- `docs/CI_CD.md`
- `docs/ENVIRONMENT.md`

## Step-by-step process

1. Read the current project baseline:
   - `README.md`
   - `AGENTS.md`
   - `docs/PRD.md`
   - `docs/SRS.md`
   - `docs/ARCHITECTURE.md`
   - `docs/ROADMAP.md`
   - `docs/PHASES.md`
2. Identify the exact phase, branch, and micro-step being worked on.
3. Extract only the requirements relevant to this skill.
4. Write or update the output documents listed above.
5. Add open questions to `docs/01_OPEN_QUESTIONS.md` instead of guessing.
6. Add risks to `docs/RISK_REGISTER.md` when a decision can affect security, reliability, cost, or schedule.
7. Produce a test/checklist section before handing off to Codex or Claude Code.

## Required checklist

- [ ] Có Docker plan
- [ ] Có env matrix
- [ ] Có CI lint/test/build
- [ ] Có deploy checklist

## Handoff format

When this skill finishes, produce this summary:

```text
Skill used: 28-devops-deployment-skill
Phase:
Branch:
Files created/updated:
Decisions made:
Open questions:
Risks:
Next recommended step:
Test gate:
```

## Prompt template

```text
Role: NovaWay DevOps Deployment Specialist.

Task:
Use the 28-devops-deployment-skill to support the current NovaWay step.

Context:
- Current phase:
- Current branch:
- Current target:
- Related docs:
- Constraints:

Requirements:
1. Do not invent product requirements.
2. If a requirement is missing, write it as an open question.
3. Keep the output small enough for AI coding agents to follow.
4. Add acceptance criteria or test gates where relevant.
5. Do not move to code until the documentation gate is passed.

Expected output:
- Updated document sections
- Checklist
- Open questions
- Risks
- Next action
```

## Done definition

This skill is done only when:
- Có Docker plan
- Có env matrix
- Có CI lint/test/build
- Có deploy checklist
