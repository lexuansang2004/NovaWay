# 13-security-compliance-review-skill — Security Compliance Review

## Purpose

Review bảo mật: auth, permission, secrets, input validation, data protection.

## When to use

Use this skill when NovaWay needs to make a decision, write a document, review a phase, or prepare a prompt related to **Security Compliance Review**.

## Inputs

- SRS
- API contract
- Data model
- Threat model

## Outputs

- `docs/SECURITY_REVIEW.md`
- `docs/SECURITY_REQUIREMENTS.md`

## Step-by-step process

1. Read the current project baseline:
   - `README.md`
   - `AGENTS.md`
   - `docs/PRD.md`
   - `docs/SRS.md`
   - `docs/ARCHITECTURE.md`
   - `docs/ROADMAP.md`
   - `docs/PHASES.md`
2. Identify the exact phase, branch, and micro-step being worked on.
3. Extract only the requirements relevant to this skill.
4. Write or update the output documents listed above.
5. Add open questions to `docs/01_OPEN_QUESTIONS.md` instead of guessing.
6. Add risks to `docs/RISK_REGISTER.md` when a decision can affect security, reliability, cost, or schedule.
7. Produce a test/checklist section before handing off to Codex or Claude Code.

## Required checklist

- [ ] Có auth/permission
- [ ] Không log secret
- [ ] Có validation
- [ ] Có privacy note

## Handoff format

When this skill finishes, produce this summary:

```text
Skill used: 13-security-compliance-review-skill
Phase:
Branch:
Files created/updated:
Decisions made:
Open questions:
Risks:
Next recommended step:
Test gate:
```

## Prompt template

```text
Role: NovaWay Security Compliance Review Specialist.

Task:
Use the 13-security-compliance-review-skill to support the current NovaWay step.

Context:
- Current phase:
- Current branch:
- Current target:
- Related docs:
- Constraints:

Requirements:
1. Do not invent product requirements.
2. If a requirement is missing, write it as an open question.
3. Keep the output small enough for AI coding agents to follow.
4. Add acceptance criteria or test gates where relevant.
5. Do not move to code until the documentation gate is passed.

Expected output:
- Updated document sections
- Checklist
- Open questions
- Risks
- Next action
```

## Done definition

This skill is done only when:
- Có auth/permission
- Không log secret
- Có validation
- Có privacy note
